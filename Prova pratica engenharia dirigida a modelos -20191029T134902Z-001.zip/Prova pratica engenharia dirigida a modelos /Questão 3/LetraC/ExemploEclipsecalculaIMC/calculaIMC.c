	 calculaIMC(){
	 }