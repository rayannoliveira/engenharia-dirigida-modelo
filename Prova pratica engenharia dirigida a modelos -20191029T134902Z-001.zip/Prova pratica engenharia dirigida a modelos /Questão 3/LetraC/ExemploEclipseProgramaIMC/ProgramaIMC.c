#include<stdio.h>
	 calculaIMC(){
	 }

	 int main (void){
	 float	altura;
	 float	peso;

}