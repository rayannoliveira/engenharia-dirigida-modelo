public	Class	Automovel{
	 public	String codigo;

}