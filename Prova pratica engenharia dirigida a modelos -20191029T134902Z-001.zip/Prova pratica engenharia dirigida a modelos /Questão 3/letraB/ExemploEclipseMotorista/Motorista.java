public	Class	Motorista{
	 public	String nomeMotorista;
	 public	void dirigir (){
	 }
}