public	Class	Carro{
	 public	String nomeCarro;
	 public	String motorista;
	 public	void ligar (){
	 }
}